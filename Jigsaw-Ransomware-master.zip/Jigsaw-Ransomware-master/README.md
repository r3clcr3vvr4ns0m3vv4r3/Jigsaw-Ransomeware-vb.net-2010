# Jigsaw-Ransomware
Warning: This project is Education purpose only, I'm not Responsible for any damage or harm

And above warning is just a joke :v


Source Code of Jigsaw Ransomware Created in Vb.Net
